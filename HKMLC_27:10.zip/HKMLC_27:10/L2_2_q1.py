"""
expected output:
2
3
4
5
6
0
1
2
3
4
"""


"""<range()>"""
# 使用 range() 列印 2到6
for number in range(______):
	print(____)

# 使用 range() 列印 0到4
for ______________
	print(____)


