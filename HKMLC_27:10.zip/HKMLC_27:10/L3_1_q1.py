"""
expected output:
4
2
The area is: 8 m^2.
"""

"""調用函數 - 計算長方形面積"""
# 定義函數 rectangleArea，傳入參數 length 和 width
def rectangleArea(length, width):
    # 建立變量計算面積
    area = _______ * _______
    # 列印面積
    print(f"The area is: {____} m^2.")

# 用 input() 讀入 length 和 width
length = input()
width = _______
# 調用函數
rectangleArea( _______, _____ )
