"""
expected output:
4
2
Area is: 8 m^2.
"""

"""使用回傳長方形面積"""
def rectangleArea(length, width):
    # 建立變量計算面積
    area = _______ * _______
    # 回傳面積
    return _____

# 使用 input()
length = _______
width = _______

# 直接使用 rectangleArea() 回傳結果
print(f"Area is {______________} m^2.")
