"""
expected_output:

apple
bread
chicken

"""


"""列出項目"""
# 建立列表變量 foods
foods = ['apple', 'bread', 'chicken']

# 使用 for 列出 foods 中的項目
for food in _________
	print(____)
