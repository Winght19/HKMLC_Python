"""
expected output:
5
10
2
The volume is: 100 m^3.
"""

"""調用函數 - 計算長方體體積"""
# 定義函數 volume，傳入參數 height、length 、width
def volume(height, _______, _______):
    # 建立變量計算面積
    volume = _______ * _______ * _______
    # 列印面積
    print(f"The volume is: {_______} m^3.")

# 用 input() 讀入 length 和 width
height = input()
length = _______
width = _______
# 調用函數
volume( _______ , _______ , ______ )
