
"""取用列表項目"""

"""
expected_output:

1 apple
1 bread
1 chicken
2 apple
2 bread
2 chicken
3 apple
3 bread
3 chicken
"""



# 建立列表變量 foods
foods = ['apple', 'bread', 'chicken']

# 大循環 - 1、2、3
for i in ____________

    # 小循環 - 列出項目
    for food in ____________

        # 列印 大循環數字 + 項目
        print(f"{____} {______}.")