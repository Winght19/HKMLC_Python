# L4.2 - question + answer
marks = [77, 80, 95, 79, 100, 34, 62, 81]
print("Marks:", marks)

# linear search 2.0
target = int(input())
found = False
i = 0
# 使用 while 迴圈逐一檢查 marks 內的每個分數


print(found)