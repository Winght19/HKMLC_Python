# L3_2_2

"""匯入 math 模組"""
# 匯入 math 模組
_______ math

# 建立變量 num，用 input() 賦值
num = _______

# 使用 math.sqrt(num) 計算 num 的開方值，賦值給變量 sqrt_value
sqrt_value = _____.sqrt(____)

# 列印
print(f"Square root of {num} is {________}")
