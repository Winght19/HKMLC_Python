# L3_2_1

"""匯入 random 模組"""
# 匯入 random 模組
_______ random
# 建立列表變量 names，初始賦值如下：
names = ["alan", "ben", "chris", "danny", "eric"]

# 使用 .choices()從 names 列表抽出一個名字賦值給 player
player = ________.______name_
# 使用 .randint()隨機生成數字（1-10），賦值給 rep
rep = ________.____________

# 列印
print(f"{player} please do push-up for {rep} times !")

