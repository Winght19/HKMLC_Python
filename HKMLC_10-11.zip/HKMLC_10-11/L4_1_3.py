# 4.1_3

"""While 版嵌套式循環"""
# 建立列表變量 foods

foods = ['apple', 'bread', 'chicken']

# 大循環 - 1、2、3
i = ____
while i____ :
# 小循環 - 列出項目
index = 0
while index____ :
# 列印 大循環數字 + 項目
print(f"{____} {______}.")
	# 循環變量 i 和 index +1 
	index = ________
i = ________
