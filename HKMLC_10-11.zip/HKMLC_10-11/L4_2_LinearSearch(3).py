# L4.2 - question + answer
marks = [77, 80, 95, 79, 100, 34, 62, 81]
print("Marks:", marks)

# linear search 3.0
target = int(input())
index = -1
# 使用 for 迴圈逐一檢查 marks 內的每個分數
# 如果找到目標分數，將 index 設為該分數的索引值並列印出來
